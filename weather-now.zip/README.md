# weather-now
A Wordpress plugin that creates a current weather in your town widget using the Open Weather API
