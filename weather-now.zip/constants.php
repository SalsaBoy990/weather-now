<?php

define('AG_WEATHER_NOW_DEBUG', 0);

define('AG_WEATHER_NOW_LOGGING', 1);

define('AG_WEATHER_NOW_PLUGIN_DIR', plugin_dir_path(__FILE__));