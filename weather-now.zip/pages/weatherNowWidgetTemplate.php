<?php
echo $before_widget;

if ($heading) {
    echo $before_title . $heading . $after_title;
}

?>

<div id="ag-weather-now-widget">

</div>

<?php

echo $after_widget;
